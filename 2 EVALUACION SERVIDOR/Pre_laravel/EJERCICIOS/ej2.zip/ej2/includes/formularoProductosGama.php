<form action="../productosController.php" method="get">
    <label for="gama">Elige una de las gamas de productos disponibles</label>
    <select id="opciones" name="opciones">
            <option value="Aromaticas">Aromáticas</option>
            <option value="Frutales">Frutales</option>
            <option value="Herbaceas">Herbaceas</option>
            <option value="Herramientas">Herramientas</option>
            <option value="Ornamentales">Ornamentales</option>
        </select>
        <input type="submit" value="Comprobar">
    </form>