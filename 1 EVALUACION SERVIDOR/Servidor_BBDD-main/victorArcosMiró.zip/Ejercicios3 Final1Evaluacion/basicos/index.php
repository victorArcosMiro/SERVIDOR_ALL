<!DOCTYPE html>
<html lang="en">
    <?php
    include('../includes/meta_datos.php');
    ?>
<body>
<?php
include('../includes/header.php');
include('../includes/nav_header.php');
?>
<section>
<?php
include('../includes/nav_basicos.php');
?>
<main>
<h3>Zona de ejercicios básicos.</h3>
<br>
<p>Aqui puedes consultar desde el menú de navegacion los ejercicios realizados en el módulo sobre programación básica</p>
</main>
<?php
include('../includes/aside.php');
?>
</section>
<?php
include('../includes/footer.php');
?>
</body>
</html>