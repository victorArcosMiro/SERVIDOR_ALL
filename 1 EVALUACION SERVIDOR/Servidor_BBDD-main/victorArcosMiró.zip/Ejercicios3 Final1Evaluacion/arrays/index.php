<!DOCTYPE html>
<html lang="en">
    <?php
    include('../includes/meta_datos.php');
    ?>
<body>
<?php
include('../includes/header.php');
include('../includes/nav_header.php');
?>
<section>
<?php
include('../includes/nav_arrays.php');
?>
<main>
<h3>Zona de ejercicios con arrays.</h3>
<br>
<p>Aquí se puede consultar desde el menu de navegación algunos de los ejercicios del módulo de programación de estructura de datos.</p>
</main>
<?php
include('../includes/aside.php');
?>
</section>
<?php
include('../includes/footer.php');
?>
</body>
</html>