<?php
echo '
<nav>
      <div class="nav">

        <div class="menu">
          <h2>MENÚ</h2>
        </div>

        <div class="temas">
        <div class="tema"><a href="index.php">INICIO.</a></div>
          <div class="tema"><a href="../basicos/index.php">básicos.</a></div>
          <div class="tema"><a href="../funciones/index.php">funciones.</a></div>
          <div class="tema"><a href="../arrays/index.php">arrays.</a></div>
          <div class="tema"><a href="../bbdd/index.php">bbdd.</a></div>
        </div>

      </div>
    </nav>
';
?>