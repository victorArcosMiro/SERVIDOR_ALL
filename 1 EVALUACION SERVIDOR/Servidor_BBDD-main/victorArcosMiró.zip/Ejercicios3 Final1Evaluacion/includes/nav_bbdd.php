<?php
echo '
<nav>
      <div class="nav">

        <div class="menu">
          <h2>BBDD</h2>
        </div>

        <div class="temas">
        <div class="tema"><a href="index.php">INICIO.</a></div>
          <div class="tema"><a href="lista_clientes.php">lista clientes.</a></div>
          <div class="tema"><a href="productos_gama.php">productos gama.</a></div>
          <div class="tema"><a href="estadistica.php">estadística.</a></div>


          <div class="tema"><a href="clientes_por_pais.php">clientes por pais.</a></div>

          <div class="tema"><a href="insertar_cliente.php">insertar cliente.</a></div>
          <div class="tema"><a href="modificar_cliente.php">modificar cliente.</a></div>
          <div class="tema"><a href="borrar_cliente.php">borrar cliente.</a></div>
          <div class="tema"><a href="pedidos_cliente.php">pedidos cliente.</a></div>



          <div class="tema"><a href="importe_pedidos.php">importe pedidos.</a></div>


        </div>

      </div>
    </nav>
';
?>