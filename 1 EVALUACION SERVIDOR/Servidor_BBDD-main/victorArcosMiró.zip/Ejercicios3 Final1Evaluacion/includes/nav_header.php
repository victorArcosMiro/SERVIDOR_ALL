<?php
echo '
<div class="nav_header">
      <ul class="barnav">
          <li class="menu_header"><a href="../main_index/index.php">inicio.</a></li>
          <li class="menu_header"><a href="../basicos/index.php">básicos.</a></li>
          <li class="menu_header"><a href="../funciones/index.php">funciones.</a></li>
          <li class="menu_header"><a href="../arrays/index.php">arrays.</a></li>
          <li class="menu_header"><a href="../bbdd/index.php">bbdd.</a></li>
      </ul>
  </div>
';
?>