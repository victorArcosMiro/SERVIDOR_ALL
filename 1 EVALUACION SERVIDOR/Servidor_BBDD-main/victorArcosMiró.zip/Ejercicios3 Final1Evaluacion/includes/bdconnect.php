<?php
            $connection = mysqli_connect("localhost", "jardinero", "jardinero", "jardineria");

?>