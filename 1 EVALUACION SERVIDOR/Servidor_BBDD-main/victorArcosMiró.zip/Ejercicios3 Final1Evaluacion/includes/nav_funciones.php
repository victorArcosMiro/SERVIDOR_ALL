<?php
echo '
<nav>
      <div class="nav">

        <div class="menu">
          <h2>FUNCIONES</h2>
        </div>

        <div class="temas">
        <div class="tema"><a href="index.php">INICIO.</a></div>
          <div class="tema"><a href="tablas_html.php">tablas html.</a></div>
          <div class="tema"><a href="cambio_divisas_funciones.php">cambio divisas.</a></div>
          <div class="tema"><a href="n_primos.php">nº primos.</a></div>
          <div class="tema"><a href="n_perfectos.php">nº perfectos.</a></div>
          <div class="tema"><a href="circulo.php">círculo.</a></div>
        </div>

      </div>
    </nav>
';
?>