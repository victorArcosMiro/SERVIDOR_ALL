<?php
echo '
<main>
<h3>PORTADA DE INICIO.</h3>
<br>
<p>Este sitio web contiene ejemplos representativos de los conocimientos adquiridos en el módulo Desarrollo Web en Entorno Servidor en 2º curso del Ciclo Formativo de <strong><em>Grado Superior Desarrollo de Aplicaciones Web.</em></strong></p>
<br>
<h3>Caracteristicas del sitio web.</h3>
<br>
<p>El sitio web dispone de un menú de cabecera para moverse por las distintas secciones y menús de navegacion en el margen izquierdo para visualizar los ejercicios de cada una de las secciones.</p>
</main>
';
?>