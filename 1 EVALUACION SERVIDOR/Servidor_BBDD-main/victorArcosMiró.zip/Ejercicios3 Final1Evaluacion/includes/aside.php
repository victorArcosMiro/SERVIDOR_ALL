<?php
echo '
<aside>
<div class="imagenes_aside">
  <div class="img_aside"><a href="https://www.php.net/"><img src="../img/aside/php.png" alt="php"></a></div>
  <div class="img_aside"><a href="https://lenguajehtml.com/html/"><img src="../img/aside/html.png" alt="html"></a></div>
  <div class="img_aside"><a href="https://www.mysql.com/"><img src="../img/aside/mysql.png" alt="mysql"></a></div>
</div>
</aside>
';
?>