<?php
echo '
<nav>
      <div class="nav">

        <div class="menu">
          <h2>BÁSICOS</h2>
        </div>

        <div class="temas">
        <div class="tema"><a href="index.php">INICIO.</a></div>
          <div class="tema"><a href="test_php.php">test php.</a></div>
          <div class="tema"><a href="conversor.php">conversor $.</a></div>
          <div class="tema"><a href="funciones.php">funciones.</a></div>
          </div>
        </div>

      </div>
    </nav>
';
?>