<?php
echo '
<nav>
      <div class="nav">

        <div class="menu">
          <h2>ARRAYS</h2>
        </div>

        <div class="temas">
        <div class="tema"><a href="index.php">INICIO.</a></div>
          <div class="tema"><a href="array_aleatorio.php">array aleatorio.</a></div>
          <div class="tema"><a href="ordenacion.php">ordenación.</a></div>
          <div class="tema"><a href="liga_futbol.php">liga futbol.</a></div>
          <div class="tema"><a href="funciones_arrays.php">funciones arrays.</a></div>
          <div class="tema"><a href="funciones_strings.php">funciones string.</a></div>
          <div class="tema"><a href="palindromos.php">palindromos.</a></div>
          <div class="tema"><a href="matrices.php">matrices.</a></div>


        </div>

      </div>
    </nav>
';
?>