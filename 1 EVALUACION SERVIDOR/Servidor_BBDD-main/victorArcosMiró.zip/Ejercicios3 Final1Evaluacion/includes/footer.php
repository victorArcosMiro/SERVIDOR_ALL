<?php
echo '
<footer>
<div class="imagenes_footer">
  <div class="img_footer"><a href="https://discord.com/"><img src="../img/footer/discord.png" alt="discord"></a></div>
  <div class="img_footer"><a href="https://www.instagram.com/"><img src="../img/footer/instagram.png" alt="instagram"></a></div>
  <div class="img_footer"><a href="https://twitter.com/"><img src="../img/footer/twitter.png" alt="twitter"></a></div>
  <div class="img_footer"><a href="https://www.whatsapp.com/"><img src="../img/footer/whatsapp.png" alt="whatsapp"></a></div>
  <div class="img_footer"><a href="https://www.youtube.com/"><img src="../img/footer/youtube.png" alt="youtube"></a></div>
</div>
<div class="autor">
  <h3>Victor Arcos Miró</h3>
</div>
</footer>
';
?>