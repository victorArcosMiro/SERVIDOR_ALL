<?php
echo '
<header>
<div class="header">
  <div class="div_logo">
    <img class="logo" src="../img/logo_obsidiana.jpg"pnlt="Logo CPILosEnlaces">
  </div>
  <div class="titulo"><h1>DESARROLLO WEB EN ENTORNO SERVIDOR</h1></div>
</div>
</header>
';
?>